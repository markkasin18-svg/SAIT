create table if not exists public.family_state (
  room_id text primary key,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.family_state enable row level security;

drop policy if exists "family_state_select" on public.family_state;
drop policy if exists "family_state_insert" on public.family_state;
drop policy if exists "family_state_update" on public.family_state;

create policy "family_state_select" on public.family_state for select to anon using (true);
create policy "family_state_insert" on public.family_state for insert to anon with check (true);
create policy "family_state_update" on public.family_state for update to anon using (true) with check (true);
